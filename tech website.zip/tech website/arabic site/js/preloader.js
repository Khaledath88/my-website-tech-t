// Arabic Preloader JavaScript
document.addEventListener('DOMContentLoaded', () => {
    const preloader = document.querySelector('.preloader');
    const loadingText = document.querySelector('.loading-text');
    const dots = document.querySelector('.dots');
    
    // Arabic loading text animation
    let dotsCount = 0;
    const updateDots = () => {
        const dotsArray = ['', '.', '..', '...'];
        dots.textContent = dotsArray[dotsCount];
        dotsCount = (dotsCount + 1) % dotsArray.length;
    };

    const dotsInterval = setInterval(updateDots, 500);

    // Hide preloader after content is loaded
    window.addEventListener('load', () => {
        clearInterval(dotsInterval);
        preloader.classList.add('fade-out');
        
        setTimeout(() => {
            preloader.style.display = 'none';
        }, 500);
    });

    // Fallback: Hide preloader after 5 seconds if load event doesn't fire
    setTimeout(() => {
        if (preloader.style.display !== 'none') {
            clearInterval(dotsInterval);
            preloader.classList.add('fade-out');
            
            setTimeout(() => {
                preloader.style.display = 'none';
            }, 500);
        }
    }, 5000);
});
