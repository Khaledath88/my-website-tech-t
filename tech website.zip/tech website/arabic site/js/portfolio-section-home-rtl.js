// Portfolio Section with RTL Support
document.addEventListener('DOMContentLoaded', function() {
    const isRTL = document.documentElement.dir === 'rtl';

    // Portfolio items data in Arabic
    const portfolioItems = [
        {
            title: "تطوير تطبيق ذكي",
            category: "تطبيقات",
            image: "../assets/images/portfolio/project1.jpg",
            description: "تطبيق ذكي متكامل مع واجهة مستخدم سلسة",
            client: "شركة التقنية المتقدمة",
            date: "٢٠٢٣",
            technologies: ["React Native", "Node.js", "MongoDB"]
        },
        {
            title: "موقع تجارة إلكترونية",
            category: "مواقع ويب",
            image: "../assets/images/portfolio/project1.jpg",
            description: "منصة تجارة إلكترونية متكاملة مع نظام دفع آمن",
            client: "متجر الإلكترونيات الحديثة",
            date: "٢٠٢٣",
            technologies: ["Vue.js", "Laravel", "MySQL"]
        },
        {
            title: "نظام إدارة المؤسسات",
            category: "برمجيات",
            image: "../assets/images/portfolio/project1.jpg",
            description: "نظام متكامل لإدارة العمليات والموارد",
            client: "مجموعة الأعمال الدولية",
            date: "٢٠٢٤",
            technologies: ["Angular", "Spring Boot", "PostgreSQL"]
        },
        {
            title: "تطبيق الواقع المعزز",
            category: "تطبيقات",
            image: "../assets/images/portfolio/project1.jpg",
            description: "تجربة واقع معزز تفاعلية للتسوق",
            client: "متاجر المستقبل",
            date: "٢٠٢٤",
            technologies: ["Unity", "ARKit", "Firebase"]
        },
        {
            title: "منصة تعليم إلكتروني",
            category: "مواقع ويب",
            image: "../assets/images/portfolio/project1.jpg",
            description: "منصة تعليمية تفاعلية مع محتوى متعدد الوسائط",
            client: "أكاديمية التعليم الرقمي",
            date: "٢٠٢٣",
            technologies: ["Next.js", "Django", "AWS"]
        },
        {
            title: "نظام إدارة المخزون",
            category: "برمجيات",
            image: "../assets/images/portfolio/project1.jpg",
            description: "نظام متطور لإدارة المخزون والتتبع",
            client: "شركة التوريدات العالمية",
            date: "٢٠٢٤",
            technologies: ["React", "Node.js", "MongoDB"]
        }
    ];

    // Filter categories in Arabic
    const categories = [
        { id: 'all', label: 'الكل' },
        { id: 'web', label: 'مواقع ويب' },
        { id: 'app', label: 'تطبيقات' },
        { id: 'software', label: 'برمجيات' }
    ];

    // Create portfolio grid
    function createPortfolioGrid() {
        const portfolioGrid = document.querySelector('.portfolio-grid');
        if (!portfolioGrid) return;

        // Create filters
        const filtersContainer = document.createElement('div');
        filtersContainer.className = 'portfolio-filters';
        
        categories.forEach(category => {
            const filterBtn = document.createElement('button');
            filterBtn.className = 'portfolio-filter-btn' + (category.id === 'all' ? ' active' : '');
            filterBtn.textContent = category.label;
            filterBtn.setAttribute('data-category', category.id);
            filtersContainer.appendChild(filterBtn);
        });

        portfolioGrid.parentNode.insertBefore(filtersContainer, portfolioGrid);

        // Create portfolio items
        portfolioItems.forEach(item => {
            const portfolioItem = document.createElement('div');
            portfolioItem.className = 'portfolio-item';
            portfolioItem.setAttribute('data-category', item.category.toLowerCase());

            portfolioItem.innerHTML = `
                <div class="portfolio-item-inner">
                    <div class="portfolio-image">
                        <img src="${item.image}" alt="${item.title}">
                        <div class="portfolio-overlay">
                            <div class="portfolio-info">
                                <h3>${item.title}</h3>
                                <p>${item.description}</p>
                                <button class="view-project">عرض المشروع</button>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            portfolioGrid.appendChild(portfolioItem);

            // Add click event for modal
            portfolioItem.querySelector('.view-project').addEventListener('click', () => {
                showProjectModal(item);
            });
        });

        // Filter functionality
        const filterButtons = document.querySelectorAll('.portfolio-filter-btn');
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const category = button.getAttribute('data-category');
                filterPortfolio(category);
                
                // Update active state
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
            });
        });
    }

    // Filter portfolio items
    function filterPortfolio(category) {
        const items = document.querySelectorAll('.portfolio-item');
        items.forEach(item => {
            const itemCategory = item.getAttribute('data-category');
            if (category === 'all' || itemCategory === category) {
                item.style.display = '';
                setTimeout(() => item.classList.add('show'), 0);
            } else {
                item.classList.remove('show');
                item.style.display = 'none';
            }
        });
    }

    // Show project modal
    function showProjectModal(project) {
        const modal = document.createElement('div');
        modal.className = 'portfolio-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <button class="modal-close">&times;</button>
                <div class="modal-body">
                    <img src="${project.image}" alt="${project.title}">
                    <div class="project-details">
                        <h2>${project.title}</h2>
                        <p>${project.description}</p>
                        <div class="project-info">
                            <div class="info-item">
                                <span class="label">العميل:</span>
                                <span class="value">${project.client}</span>
                            </div>
                            <div class="info-item">
                                <span class="label">التاريخ:</span>
                                <span class="value">${project.date}</span>
                            </div>
                            <div class="info-item">
                                <span class="label">التقنيات:</span>
                                <span class="value">${project.technologies.join(', ')}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        setTimeout(() => modal.classList.add('show'), 0);

        // Close modal
        const closeBtn = modal.querySelector('.modal-close');
        closeBtn.addEventListener('click', () => {
            modal.classList.remove('show');
            setTimeout(() => modal.remove(), 300);
        });

        // Close on outside click
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeBtn.click();
            }
        });
    }

    // Initialize portfolio
    createPortfolioGrid();
});
