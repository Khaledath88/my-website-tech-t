// Hero Section JavaScript with RTL Support
document.addEventListener('DOMContentLoaded', function() {
    const isRTL = document.documentElement.dir === 'rtl';
    const heroSlider = document.querySelector('.hero-slider');
    const slides = document.querySelectorAll('.hero-slide');
    const prevBtn = document.querySelector('.hero-control.prev');
    const nextBtn = document.querySelector('.hero-control.next');
    const dots = document.querySelectorAll('.hero-dot');
    let currentSlide = 0;
    let slideInterval;

    // Initialize slider
    function initSlider() {
        slides[0].classList.add('active');
        updateDots();
        startSlideTimer();
    }

    // Update dots
    function updateDots() {
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentSlide);
        });
    }

    // Handle slide transition
    function transitionSlide(next) {
        const direction = isRTL ? -1 : 1;
        slides[currentSlide].classList.remove('active');
        currentSlide = next;
        slides[currentSlide].classList.add('active');
        updateDots();
    }

    // Next slide
    function nextSlide() {
        const next = (currentSlide + 1) % slides.length;
        transitionSlide(next);
    }

    // Previous slide
    function prevSlide() {
        const next = (currentSlide - 1 + slides.length) % slides.length;
        transitionSlide(next);
    }

    // Start auto-slide timer
    function startSlideTimer() {
        if (slideInterval) {
            clearInterval(slideInterval);
        }
        slideInterval = setInterval(nextSlide, 5000);
    }

    // Event Listeners
    if (isRTL) {
        // Swap next and prev for RTL
        nextBtn.addEventListener('click', prevSlide);
        prevBtn.addEventListener('click', nextSlide);
    } else {
        nextBtn.addEventListener('click', nextSlide);
        prevBtn.addEventListener('click', prevSlide);
    }

    // Dot navigation
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            if (index !== currentSlide) {
                transitionSlide(index);
                startSlideTimer();
            }
        });
    });

    // Pause on hover
    heroSlider.addEventListener('mouseenter', () => {
        clearInterval(slideInterval);
    });

    heroSlider.addEventListener('mouseleave', startSlideTimer);

    // Initialize the slider
    initSlider();
});
