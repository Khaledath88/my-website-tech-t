# Tech Website Project

A modern tech website built with Bootstrap 5.

## Project Structure

```
tech-website/
├── index.html          # Home page
├── about.html          # About page
├── services.html       # Services page (to be created)
├── blog.html          # Blog page (to be created)
├── contact.html       # Contact page (to be created)
├── css/
│   └── style.css      # Custom styles
├── js/
│   └── main.js        # Custom JavaScript
└── assets/            # Images and other media files
    ├── images/
    └── icons/
```

## Technologies Used

- HTML5
- CSS3
- Bootstrap 5.3.2
- JavaScript

## Getting Started

1. Clone this repository
2. Open `index.html` in your web browser
3. Start customizing the content and styles

## Features

- Responsive design
- Modern UI
- Cross-browser compatibility
- Mobile-first approach
